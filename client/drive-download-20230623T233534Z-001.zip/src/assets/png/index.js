import loginLogo from "./undraw_Login_re_4vu2.png";

export { loginLogo };
