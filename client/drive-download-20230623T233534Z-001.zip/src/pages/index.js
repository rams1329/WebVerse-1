import LandingPage from "./LandingPage";
import PageNotFound from "./PageNotFound";

export { PageNotFound, LandingPage };
